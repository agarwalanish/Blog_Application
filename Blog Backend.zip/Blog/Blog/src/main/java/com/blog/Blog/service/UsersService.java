package com.blog.Blog.service;


import com.blog.Blog.entity.Users;
import com.blog.Blog.repository.UsersRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
@Service
public class UsersService {

    @Autowired
    UsersRepo userRepo;
    PasswordEncoder passwordEncoder = new BCryptPasswordEncoder();
    public Users saveUser(Users user){
        user.setPassword(this.passwordEncoder.encode(user.getPassword()));
        return userRepo.save(user);
    }

    public  int authenticate(Users user) {
        Users u = userRepo.findById(user.getUserId()).get();
//        System.out.println(u);
//        System.out.println(u.getPassword());
//        System.out.println(user.getPassword());
        String enpass=u.getPassword();
        String pass = user.getPassword();
        if (this.passwordEncoder.matches(pass,enpass))
            return u.getUserId();
        else
            return -1;
    }
}
