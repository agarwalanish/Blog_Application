package com.blog.Blog.controller;


import com.blog.Blog.entity.Users;
import com.blog.Blog.service.UsersService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UsersController {

    @Autowired
    UsersService usersService;


    @PostMapping("/user/addUser")
    public Users saveUser(@RequestBody Users user){
        return usersService.saveUser(user);
    }

    @PostMapping("/user/Authenticate")
    public int  Authenticate(@RequestBody Users user)
    {
        return usersService.authenticate(user);
    }
}
