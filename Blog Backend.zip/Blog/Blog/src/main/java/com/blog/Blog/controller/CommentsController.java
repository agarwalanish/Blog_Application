package com.blog.Blog.controller;

import com.blog.Blog.entity.Comments;
import com.blog.Blog.service.CommentsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.time.LocalTime;
import java.util.List;

@RestController
@CrossOrigin(origins = "*")
public class CommentsController {

    @Autowired
    CommentsService commentsService;


    @PostMapping("user/addComment")
    public void addComment(@RequestBody Comments comment)
    {
        commentsService.addComment(comment);
    }


    @GetMapping("user/viewComments")
    public List<Comments> viewComments(@RequestParam(value = "blogId") int blogId)
    {
       return  commentsService.viewComments(blogId);
    }


    // delete other's comments in their post
    @DeleteMapping("user/deleteComment")
    public void deleteComment(@RequestParam(value = "commentId") int commentId)
    {
        commentsService.deleteComment(commentId);
    }


    // delete your comment within a minute
    @DeleteMapping("user/deleteMyComment")
    public boolean deleteMyComment(@RequestParam(value = "commentId")int commentId,@RequestParam(value = "time") String temp)
    {
        LocalTime time= LocalTime.parse(temp);
        return commentsService.deleteMyComment(commentId,time);
    }
}
