package com.blog.Blog.repository;

import com.blog.Blog.entity.Blogs;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface BlogsRepo extends JpaRepository<Blogs, Integer> {
    List<Blogs> findByUserId(int userId);

//    Blogs findByUser_idAndBlog_id(int user_id, int blog_id);
}
