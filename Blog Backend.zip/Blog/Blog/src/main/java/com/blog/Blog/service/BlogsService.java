package com.blog.Blog.service;

import com.blog.Blog.entity.Blogs;
import com.blog.Blog.repository.BlogsRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class BlogsService {
    @Autowired
    BlogsRepo blogsRepo;
    public List<Blogs> viewMyBlogs(int userId) {
        return blogsRepo.findByUserId(userId);
    }

    public Blogs viewBlog(int blogId) {
        return blogsRepo.findById(blogId).get();
    }

    public void updateBlog(Blogs blog) {
        Blogs temp = blogsRepo.findById(blog.getBlogId()).get();
        temp.setContent(blog.getContent());
        blogsRepo.save(temp);
    }

    public List<Blogs> viewOtherBlogs(int userId) {
        List<Blogs> blogs=blogsRepo.findAll();
        List<Blogs> otherBlogs = new ArrayList<>();
        for(int x=0;x< blogs.size();x++)
        {
            if(blogs.get(x).getUserId() != userId)
            {
                otherBlogs.add(blogs.get(x));
            }
        }
        return otherBlogs;
    }
}
