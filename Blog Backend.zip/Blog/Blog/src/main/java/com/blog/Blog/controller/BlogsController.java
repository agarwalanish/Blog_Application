package com.blog.Blog.controller;

import com.blog.Blog.entity.Blogs;
import com.blog.Blog.service.BlogsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@CrossOrigin(origins = "*")
public class BlogsController {

    @Autowired
    BlogsService blogsService;
    // View their blogs
    @GetMapping("user/viewMyBlogs")
    public List<Blogs> viewMyBlogs(@RequestParam(value = "userId") int userId)
    {
//        int userId=Integer.parseInt(id);
        return blogsService.viewMyBlogs(userId);
    }


    // View a blog + edit a blog
    @GetMapping("user/viewBlog")
    public Blogs viewBlog(@RequestParam(value = "blogId") int blogId)
    {
        return blogsService.viewBlog(blogId);
    }


    // Use this controller for updating blogs and adding a blog / edit a blog
    @PostMapping("user/updateBlog")
    public void updateBlog(@RequestBody Blogs blog)
    {
        blogsService.updateBlog(blog);
    }


    @GetMapping("user/viewOtherBlogs")
    public List<Blogs> viewOtherBlogs(@RequestParam(value = "userId") int userId)
    {
        return blogsService.viewOtherBlogs(userId);
    }
}
