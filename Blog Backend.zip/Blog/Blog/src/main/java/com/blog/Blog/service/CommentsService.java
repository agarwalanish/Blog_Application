package com.blog.Blog.service;


import com.blog.Blog.entity.Comments;
import com.blog.Blog.repository.CommentsRepo;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalTime;
import java.util.List;

@Service
public class CommentsService {

    @Autowired
    CommentsRepo commentsRepo;
    public void addComment(Comments comment) {
        commentsRepo.save(comment);
    }

    public List<Comments> viewComments(int blogId) {
        return commentsRepo.findByBlogId(blogId);
    }

    public void deleteComment(int commentId) {
        Comments comment = commentsRepo.findById(commentId).get();
        commentsRepo.delete(comment);
    }

    public boolean deleteMyComment(int commentId, LocalTime time) {
        Comments comment = commentsRepo.findById(commentId).get();
        if((time.getMinute() - comment.getTime().getMinute())==0)
        {
            commentsRepo.delete(comment);
             return true;
        }
        else
        {
            return false;
        }
    }
}
