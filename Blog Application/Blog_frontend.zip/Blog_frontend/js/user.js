let app = angular.module('UserApp',[]);


app.controller("UserCtrl",($scope, $http, $window)=>{

    $http.defaults.headers.post["Content-Type"] = "application/json";
    const params = new URLSearchParams(document.location.search);
    const id = params.get("id");
    $scope.uid=id;
    $scope.currMin = new Date().getMinutes();
    console.log(id);
    $scope.link1='http://127.0.0.1:5500/user.html?id='+id;
    $scope.link2='http://127.0.0.1:5500/feed.html?id='+id;
    $scope.link3='http://127.0.0.1:5500/update.html?id='+id
    $scope.temp=false;
    $scope.ViewMyBlogs =()=>{
        $http.get("http://www.localhost:8080/user/viewMyBlogs", {params:{"userId": id}}).then((data)=>{
            console.log(data.data);
            $scope.recievedJSON=data.data;
        })
    };

    $scope.ViewOtherBlogs =()=>{
        $http.get("http://www.localhost:8080/user/viewOtherBlogs", {params:{"userId": id}}).then((data)=>{
            console.log(data.data);
            $scope.recievedJSON=data.data;
        })
    };

    $scope.redirect=(blogId)=>{
        $window.location.href = "http://127.0.0.1:5500/blog.html?id="+id+"&blogId="+blogId;
    }

    $scope.redirectupdate=(blogId)=>{
        $window.location.href = "http://127.0.0.1:5500/update.html?id="+id+"&blogId="+blogId;
    }

    $scope.ViewBlog=()=>{
        const params = new URLSearchParams(document.location.search);
        const blogId = params.get("blogId");
        console.log(blogId);
        $http.get("http://www.localhost:8080/user/viewBlog",  {params:{"blogId": blogId}}).then((data)=>{
            console.log(data.data);
            $scope.recievedBlog=data.data;     
            $scope.title=($scope.recievedBlog).title;  
            $scope.content=($scope.recievedBlog).content;      
        })
    };

    
    $scope.DeleteBlog=(blogId)=>{
        $http.delete("http://www.localhost:8080/user/deleteBlog",  {params:{"blogId": blogId}}).then((data)=>{
            location.reload();
        })
    };

    $scope.ViewComments =()=>{
        const params = new URLSearchParams(document.location.search);
        const blogId = params.get("blogId");
        $http.get("http://www.localhost:8080/user/viewComments", {params:{"blogId": blogId}}).then((data)=>{
            console.log(data.data);
            $scope.recievedComments=data.data;
        })
    };

    $scope.DeleteComment=(commentId)=>{
        $http.delete("http://www.localhost:8080/user/deleteComment",  {params:{"commentId": commentId}}).then((data)=>{
            location.reload();
        })
    };

    $scope.AddComment=(content,blogId)=>{
        if(content==null||blogId==null)
        {
            location.reload();
            alert("Null Values");
            console.log("Null Values"); 
        }
        else{
        var data={
            blogId :blogId,
            userId :id,
            comment :content,
            minute : new Date().getMinutes()
        };
            console.log(typeof(new Date().getMinutes()))
            console.log(new Date().getMinutes())
        $http.post('http://www.localhost:8080/user/addComment',JSON.stringify(data)).then( function(success) {
            location.reload();
                alert("Data Submitted Successfully!");
                console.log("Success");

            },
            function (error){
                location.reload();
                alert("Failed to submit!");
                console.log("Failure");            
            }
        );
        };

    };

    $scope.UpdateBlog=(title, content)=>{
        const params = new URLSearchParams(document.location.search);
        const blogId = params.get("blogId");
        console.log(title);
        if(title==null||content==null)
        {
            // location.reload();
            alert("Null Values");
            console.log("Null Values"); 
        }
        else{
        var data={
            blogId :blogId,
            userId :id,
            content :content,
            title : title
        }
       
        $http.post('http://www.localhost:8080/user/updateBlog', JSON.stringify(data) ).then((success)=>{
            console.log(success);
            alert("Updated Successfully");
            $window.location.href = "http://127.0.0.1:5500/blog.html?id="+id+"&blogId="+blogId;
        })
    }
};

});
